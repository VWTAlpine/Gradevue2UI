export interface AuthToken {
	_EncyToken: string;
}
