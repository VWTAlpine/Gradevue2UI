<p>
	Use your StudentVue password to
	<a href="/login" class="text-primary-600 underline">log in</a>.
</p>
